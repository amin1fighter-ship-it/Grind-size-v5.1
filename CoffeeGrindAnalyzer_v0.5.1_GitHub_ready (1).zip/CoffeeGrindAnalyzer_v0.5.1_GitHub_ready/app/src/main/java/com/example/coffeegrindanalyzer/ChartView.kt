package com.example.coffeegrindanalyzer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class ChartView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    var samples: List<Sample> = emptyList()
        set(value) { field = value.sortedBy { it.date }; invalidate() }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 5f; style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 28f; style = Paint.Style.FILL }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 2f; style = Paint.Style.STROKE }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(0xFF111111.toInt())
        if (samples.isEmpty()) { c.drawText("داده‌ای برای نمودار وجود ندارد", 30f, 50f, text); return }
        val l=70f; val r=width-30f; val t=45f; val b=height-65f
        val maxV=max(1.0, samples.maxOf { max(it.d10, max(it.d50, it.d90)) })
        for (i in 0..4) { val y=b-(b-t)*i/4f; c.drawLine(l,y,r,y,grid); c.drawText("${(maxV*i/4).toInt()}",5f,y-5,text) }
        fun drawSeries(get:(Sample)->Double, label:String, yoff:Float) {
            val p=Path(); samples.forEachIndexed { i,s ->
                val x=if(samples.size==1) (l+r)/2 else l+(r-l)*i/(samples.size-1)
                val y=b-(b-t)*(get(s)/maxV).toFloat()
                if(i==0)p.moveTo(x,y) else p.lineTo(x,y)
            }; c.drawPath(p,line); c.drawText(label,r-170,yoff,text)
        }
        drawSeries({it.d10},"D10",28f); drawSeries({it.d50},"D50",56f); drawSeries({it.d90},"D90",84f)
        samples.forEachIndexed { i,s -> val x=if(samples.size==1)(l+r)/2 else l+(r-l)*i/(samples.size-1); c.drawText((i+1).toString(),x-8,b+35,text) }
    }
}
