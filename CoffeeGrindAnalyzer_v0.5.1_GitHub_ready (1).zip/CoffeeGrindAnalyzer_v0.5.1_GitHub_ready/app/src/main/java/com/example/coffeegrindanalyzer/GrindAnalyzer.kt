package com.example.coffeegrindanalyzer

import android.graphics.Bitmap
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import java.util.Locale
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Coffee Grind Analyzer v0.5
 *
 * Pipeline:
 *  1) Detect the 100 x 100 mm reference square.
 *  2) Perspective-warp to a fixed 2000 x 2000 px plane (50 um/px).
 *  3) Build a robust foreground mask using Otsu + adaptive threshold selection.
 *  4) Use distance-transform + watershed to split touching grounds.
 *  5) Measure each watershed region by equivalent circular diameter (ECD).
 *  6) Report Number PSD, Area PSD and image-volume-proxy PSD.
 *
 * This is an image-based analyzer, not a laboratory mass/volume analyzer.
 */
object GrindAnalyzer {
    private var openCvReady = false

    fun ensureLoaded(): Boolean {
        if (!openCvReady) openCvReady = OpenCVLoader.initLocal()
        return openCvReady
    }

    private const val WARP_SIZE = 2000
    private const val MIN_DIAMETER_UM = 80.0
    private const val MAX_DIAMETER_UM = 5000.0

    fun analyze(bitmap: Bitmap, squareMm: Double): String {
        if (!ensureLoaded()) return "خطا: OpenCV بارگذاری نشد."

        val src = Mat()
        Utils.bitmapToMat(bitmap, src)
        Imgproc.cvtColor(src, src, Imgproc.COLOR_RGBA2RGB)

        val gray = Mat()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_RGB2GRAY)
        Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 0.0)

        val corners = findSquareCorners(gray)
            ?: return "مربع مرجع پیدا نشد. کل مربع ۱۰۰×۱۰۰ داخل فریم باشد و نور یکنواخت باشد."

        val warped = warpToSquare(src, corners, WARP_SIZE)
        val warpedGray = Mat()
        Imgproc.cvtColor(warped, warpedGray, Imgproc.COLOR_RGB2GRAY)

        // Mild blur: enough to suppress JPEG noise without erasing small grounds.
        Imgproc.GaussianBlur(warpedGray, warpedGray, Size(3.0, 3.0), 0.0)

        val mask = buildForegroundMask(warpedGray)
        stripBorder(mask)

        // Tiny cleanup only; do NOT use a large opening because it destroys fines.
        val tinyKernel = Imgproc.getStructuringElement(
            Imgproc.MORPH_ELLIPSE, Size(2.0, 2.0)
        )
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_OPEN, tinyKernel)

        val diameters = watershedDiameters(warpedGray, mask, squareMm)

        src.release()
        gray.release()
        warped.release()
        warpedGray.release()
        mask.release()
        tinyKernel.release()

        if (diameters.size < 5) {
            return "ذرات کافی تشخیص داده نشد. فوکوس، نور و تراکم سابه را بررسی کن."
        }

        return buildReport(diameters)
    }

    /**
     * Uses both Otsu and adaptive thresholding and chooses the mask whose
     * foreground ratio falls into a plausible range for scattered coffee grounds.
     */
    private fun buildForegroundMask(gray: Mat): Mat {
        val otsu = Mat()
        Imgproc.threshold(
            gray, otsu, 0.0, 255.0,
            Imgproc.THRESH_BINARY_INV + Imgproc.THRESH_OTSU
        )

        val adaptive = Mat()
        Imgproc.adaptiveThreshold(
            gray, adaptive, 255.0,
            Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C,
            Imgproc.THRESH_BINARY_INV,
            51, 8.0
        )

        val otsuRatio = Core.countNonZero(otsu).toDouble() / (gray.rows() * gray.cols())
        val adaptiveRatio = Core.countNonZero(adaptive).toDouble() / (gray.rows() * gray.cols())

        // For the paper setup, coffee should occupy a minority of the square.
        val chosen = when {
            otsuRatio in 0.005..0.45 -> otsu
            adaptiveRatio in 0.005..0.45 -> adaptive
            else -> if (otsuRatio < adaptiveRatio) otsu else adaptive
        }

        if (chosen !== otsu) otsu.release()
        if (chosen !== adaptive) adaptive.release()
        return chosen
    }

    private fun stripBorder(mask: Mat) {
        val b = (WARP_SIZE * 0.015).toInt().coerceAtLeast(8)
        Imgproc.rectangle(mask, Point(0.0, 0.0),
            Point(WARP_SIZE.toDouble(), b.toDouble()), Scalar(0.0), -1)
        Imgproc.rectangle(mask, Point(0.0, 0.0),
            Point(b.toDouble(), WARP_SIZE.toDouble()), Scalar(0.0), -1)
        Imgproc.rectangle(mask, Point(0.0, (WARP_SIZE - b).toDouble()),
            Point(WARP_SIZE.toDouble(), WARP_SIZE.toDouble()), Scalar(0.0), -1)
        Imgproc.rectangle(mask, Point((WARP_SIZE - b).toDouble(), 0.0),
            Point(WARP_SIZE.toDouble(), WARP_SIZE.toDouble()), Scalar(0.0), -1)
    }

    private fun watershedDiameters(gray: Mat, mask: Mat, squareMm: Double): List<Double> {
        val kernel = Imgproc.getStructuringElement(
            Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0)
        )

        // Sure background: a small dilation around the binary grounds.
        val sureBg = Mat()
        Imgproc.dilate(mask, sureBg, kernel, Point(-1.0, -1.0), 2)

        // Distance transform. Lower seed threshold than v0.4 to reduce under-segmentation.
        val dist = Mat()
        Imgproc.distanceTransform(mask, dist, Imgproc.DIST_L2, 5)
        val maxVal = Core.minMaxLoc(dist).maxVal

        val sureFg = Mat()
        if (maxVal <= 0.0) return emptyList()
        Imgproc.threshold(dist, sureFg, 0.28 * maxVal, 255.0, Imgproc.THRESH_BINARY)
        sureFg.convertTo(sureFg, CvType.CV_8U)

        val unknown = Mat()
        Core.subtract(sureBg, sureFg, unknown)

        val markers = Mat()
        Imgproc.connectedComponents(sureFg, markers)
        Core.add(markers, Scalar(1.0), markers)
        markers.setTo(Scalar(0.0), unknown)

        val wsImage = Mat()
        Imgproc.cvtColor(gray, wsImage, Imgproc.COLOR_GRAY2RGB)
        Imgproc.watershed(wsImage, markers)

        val labels = IntArray(WARP_SIZE * WARP_SIZE)
        markers.get(0, 0, labels)

        val areas = HashMap<Int, Int>()
        for (v in labels) if (v >= 2) {
            areas[v] = (areas[v] ?: 0) + 1
        }

        val pxPerMm = WARP_SIZE.toDouble() / squareMm
        val pxAreaPerMm2 = pxPerMm * pxPerMm

        val diameters = areas.values.mapNotNull { areaPx ->
            // Very small regions are mostly watershed fragments/noise.
            if (areaPx < 3) return@mapNotNull null
            val areaMm2 = areaPx / pxAreaPerMm2
            val dUm = sqrt(4.0 * areaMm2 / PI) * 1000.0
            if (dUm in MIN_DIAMETER_UM..MAX_DIAMETER_UM) dUm else null
        }.sorted()

        kernel.release()
        sureBg.release()
        dist.release()
        sureFg.release()
        unknown.release()
        markers.release()
        wsImage.release()
        return diameters
    }

    private fun findSquareCorners(gray: Mat): Array<Point>? {
        val edges = Mat()
        Imgproc.Canny(gray, edges, 50.0, 150.0)

        val contours = ArrayList<MatOfPoint>()
        val hierarchy = Mat()
        Imgproc.findContours(
            edges, contours, hierarchy,
            Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE
        )

        val frameArea = gray.rows().toDouble() * gray.cols().toDouble()
        var best: Array<Point>? = null
        var bestScore = 0.0

        for (c in contours) {
            val area = abs(Imgproc.contourArea(c))
            if (area < frameArea * 0.10 || area > frameArea * 0.98) continue

            val c2f = MatOfPoint2f(*c.toArray())
            val peri = Imgproc.arcLength(c2f, true)
            val approx = MatOfPoint2f()
            Imgproc.approxPolyDP(c2f, approx, 0.025 * peri, true)

            if (approx.total() == 4L && Imgproc.isContourConvex(MatOfPoint(*approx.toArray()))) {
                val pts = approx.toArray()
                val w1 = distance(pts[0], pts[1])
                val w2 = distance(pts[2], pts[3])
                val h1 = distance(pts[1], pts[2])
                val h2 = distance(pts[3], pts[0])
                val w = (w1 + w2) / 2.0
                val h = (h1 + h2) / 2.0
                if (w <= 0 || h <= 0) continue

                val aspect = minOf(w, h) / maxOf(w, h)
                if (aspect < 0.65) continue

                // Prefer large, square-ish contours.
                val score = area * (0.5 + 0.5 * aspect)
                if (score > bestScore) {
                    bestScore = score
                    best = orderCorners(pts)
                }
            }
            approx.release()
            c2f.release()
        }

        edges.release()
        hierarchy.release()
        return best
    }

    private fun distance(a: Point, b: Point): Double =
        hypot(a.x - b.x, a.y - b.y)

    private fun orderCorners(pts: Array<Point>): Array<Point> {
        val bySum = pts.sortedBy { it.x + it.y }
        val tl = bySum.first()
        val br = bySum.last()
        val byDiff = pts.sortedBy { it.y - it.x }
        val tr = byDiff.first()
        val bl = byDiff.last()
        return arrayOf(tl, tr, br, bl)
    }

    private fun warpToSquare(src: Mat, corners: Array<Point>, size: Int): Mat {
        val srcMat = MatOfPoint2f(*corners)
        val dstMat = MatOfPoint2f(
            Point(0.0, 0.0),
            Point((size - 1).toDouble(), 0.0),
            Point((size - 1).toDouble(), (size - 1).toDouble()),
            Point(0.0, (size - 1).toDouble())
        )
        val transform = Imgproc.getPerspectiveTransform(srcMat, dstMat)
        val dst = Mat()
        Imgproc.warpPerspective(src, dst, transform, Size(size.toDouble(), size.toDouble()))
        srcMat.release()
        dstMat.release()
        transform.release()
        return dst
    }

    private fun buildReport(diameters: List<Double>): String {
        fun percentile(list: List<Double>, p: Double): Double {
            val pos = p * (list.size - 1)
            val lo = pos.toInt()
            val hi = kotlin.math.ceil(pos).toInt()
            return if (lo == hi) list[lo]
            else list[lo] + (list[hi] - list[lo]) * (pos - lo)
        }

        fun rangeCount(a: Double, b: Double): Double =
            100.0 * diameters.count { it >= a && it < b } / diameters.size

        val weights = diameters.map { it.pow(2.0) } // area-weighted image PSD
        val totalArea = weights.sum()

        fun areaPercentile(p: Double): Double {
            var cumulative = 0.0
            val target = totalArea * p
            for (i in diameters.indices) {
                cumulative += weights[i]
                if (cumulative >= target) return diameters[i]
            }
            return diameters.last()
        }

        fun areaRange(a: Double, b: Double): Double =
            100.0 * diameters.indices
                .filter { diameters[it] >= a && diameters[it] < b }
                .sumOf { weights[it] } / totalArea

        // Image-volume proxy is shown separately, not presented as laboratory mass PSD.
        val volumes = diameters.map { it.pow(3.0) }
        val totalVolume = volumes.sum()
        fun volumePercentile(p: Double): Double {
            var cumulative = 0.0
            val target = totalVolume * p
            for (i in diameters.indices) {
                cumulative += volumes[i]
                if (cumulative >= target) return diameters[i]
            }
            return diameters.last()
        }

        fun volumeRange(a: Double, b: Double): Double =
            100.0 * diameters.indices
                .filter { diameters[it] >= a && diameters[it] < b }
                .sumOf { volumes[it] } / totalVolume

        val n10 = percentile(diameters, .10)
        val n50 = percentile(diameters, .50)
        val n90 = percentile(diameters, .90)

        return String.format(
            Locale.US,
            "Coffee Grind Analyzer v0.5\n\n" +
            "ذرات قابل تفکیک: %d\n" +
            "مقیاس: مربع مرجع %.0f×%.0f mm\n" +
            "تفکیک تصویر پس از warp: %.0f µm/pixel\n\n" +
            "Number PSD\nD10: %.0f µm\nD50: %.0f µm\nD90: %.0f µm\n\n" +
            "Area-weighted image PSD\nD10: %.0f µm\nD50: %.0f µm\nD90: %.0f µm\n\n" +
            "Volume-proxy image PSD\nD10: %.0f µm\nD50: %.0f µm\nD90: %.0f µm\n\n" +
            "توزیع تعدادی:\n" +
            "<300 µm: %.1f%%\n300–800 µm: %.1f%%\n800–1200 µm: %.1f%%\n>1200 µm: %.1f%%\n\n" +
            "توزیع سطح تصویری:\n" +
            "<300 µm: %.1f%%\n300–800 µm: %.1f%%\n800–1200 µm: %.1f%%\n>1200 µm: %.1f%%\n\n" +
            "توزیع حجم‌-پروکسی:\n" +
            "<300 µm: %.1f%%\n300–800 µm: %.1f%%\n800–1200 µm: %.1f%%\n>1200 µm: %.1f%%\n\n" +
            "✓ square detection + perspective correction + adaptive/Otsu mask + watershed\n" +
            "⚠️ این خروجی تصویرمحور است؛ Volume-proxy معادل PSD جرمی آزمایشگاهی نیست.",
            diameters.size,
            100.0, 100.0, 50.0,
            n10, n50, n90,
            areaPercentile(.10), areaPercentile(.50), areaPercentile(.90),
            volumePercentile(.10), volumePercentile(.50), volumePercentile(.90),
            rangeCount(0.0, 300.0), rangeCount(300.0, 800.0),
            rangeCount(800.0, 1200.0), rangeCount(1200.0, Double.POSITIVE_INFINITY),
            areaRange(0.0, 300.0), areaRange(300.0, 800.0),
            areaRange(800.0, 1200.0), areaRange(1200.0, Double.POSITIVE_INFINITY),
            volumeRange(0.0, 300.0), volumeRange(300.0, 800.0),
            volumeRange(800.0, 1200.0), volumeRange(1200.0, Double.POSITIVE_INFINITY)
        )
    }
}
