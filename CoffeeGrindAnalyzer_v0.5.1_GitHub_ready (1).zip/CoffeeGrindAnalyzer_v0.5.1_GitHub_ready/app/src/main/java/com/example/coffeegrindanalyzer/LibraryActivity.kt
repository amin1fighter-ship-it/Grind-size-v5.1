package com.example.coffeegrindanalyzer

import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class LibraryActivity : androidx.activity.ComponentActivity() {
    private lateinit var db: SampleDb
    private lateinit var list: LinearLayout
    override fun onCreate(b: Bundle?) { super.onCreate(b); db=SampleDb(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(20,20,20,20)}
        val title=TextView(this).apply{text="☕ کتابخانه نمونه‌ها";textSize=24f;setPadding(0,0,0,18)}; root.addView(title)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; root.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }
    override fun onResume(){super.onResume(); if(::list.isInitialized)render()}
    private fun render(){ list.removeAllViews(); val groups=db.coffees(); if(groups.isEmpty()){list.addView(TextView(this).apply{text="هنوز نمونه‌ای ذخیره نشده.";textSize=18f});return}
        groups.forEach{(coffee,count)-> val b=Button(this).apply{text="☕ $coffee   ($count تست)";setOnClickListener{showCoffee(coffee)}};list.addView(b,ViewGroup.LayoutParams(-1,70)) }
    }
    private fun showCoffee(coffee:String){ val samples=db.byCoffee(coffee); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(15,15,15,15)}
        val chart=ChartView(this).apply{samples=samples}; box.addView(chart,LinearLayout.LayoutParams(-1,420))
        val info=TextView(this).apply{textSize=16f;text="سیر تغییرات: D10 / D50 / D90\n"+samples.mapIndexed{ i,s->"${i+1}. ${s.grinder} | ${s.setting} | D50=${s.d50.toInt()} µm"}.joinToString("\n")};box.addView(info)
        val scroll=ScrollView(this).apply{addView(box)}; AlertDialog.Builder(this).setTitle(coffee).setView(scroll).setPositiveButton("بستن",null).show()
    }
}
