package com.example.coffeegrindanalyzer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern

class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var instruction: TextView
    private lateinit var resultText: TextView
    private lateinit var saveButton: Button
    private var imageCapture: ImageCapture? = null
    private var lastReport: String? = null
    private var lastImagePath: String? = null
    private lateinit var db: SampleDb

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else instruction.text = "اجازه دوربین لازم است."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        db=SampleDb(this)
        previewView=findViewById(R.id.preview); instruction=findViewById(R.id.instruction); resultText=findViewById(R.id.resultText); saveButton=findViewById(R.id.saveButton)
        findViewById<Button>(R.id.captureButton).setOnClickListener{captureAndAnalyze()}
        findViewById<Button>(R.id.libraryButton).setOnClickListener{startActivity(android.content.Intent(this,LibraryActivity::class.java))}
        saveButton.setOnClickListener{showSaveDialog()}
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera(){
        val future=ProcessCameraProvider.getInstance(this); future.addListener({
            val provider=future.get(); val preview=Preview.Builder().build(); preview.setSurfaceProvider(previewView.surfaceProvider)
            imageCapture=ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
            provider.unbindAll(); provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,preview,imageCapture)
        },ContextCompat.getMainExecutor(this))
    }

    private fun captureAndAnalyze(){
        val capture=imageCapture?:return; resultText.visibility=View.GONE; saveButton.visibility=View.GONE; instruction.text="در حال عکس‌برداری و تحلیل…"
        val file=File(cacheDir,"grind_${System.currentTimeMillis()}.jpg"); val output=ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(output,ContextCompat.getMainExecutor(this),object:ImageCapture.OnImageSavedCallback{
            override fun onError(exc:ImageCaptureException){instruction.text="خطا: ${exc.message}"}
            override fun onImageSaved(result:ImageCapture.OutputFileResults){
                try{
                    val bmp=BitmapFactory.decodeFile(file.absolutePath); val report=GrindAnalyzer.analyze(bmp,100.0)
                    lastReport=report
                    val permanent=File(File(filesDir,"samples").apply{mkdirs()},"${System.currentTimeMillis()}.jpg"); file.copyTo(permanent,true); lastImagePath=permanent.absolutePath
                    instruction.text="تحلیل تمام شد. اگر نمونه را می‌خواهی در لاگ نگه داری، «ذخیره نمونه» را بزن."
                    resultText.text=report; resultText.visibility=View.VISIBLE; saveButton.visibility=View.VISIBLE
                }catch(e:Exception){instruction.text="خطا در تحلیل: ${e.message}";file.delete()}
            }
        })
    }

    private fun num(label:String, report:String):Double{
        val p=Pattern.compile(Pattern.quote(label)+"\\s*([0-9]+(?:\\.[0-9]+)?)"); val m=p.matcher(report); return if(m.find())m.group(1).toDouble() else 0.0
    }
    private fun particles(report:String):Int{val m=Pattern.compile("ذرات قابل تفکیک:\\s*(\\d+)").matcher(report);return if(m.find())m.group(1).toInt() else 0}

    private fun showSaveDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(35,10,35,0)}
        fun field(hint:String)=EditText(this).apply{this.hint=hint;setSingleLine(true)}
        val coffee=field("نام قهوه *"); val grinder=field("نام آسیاب *"); val setting=field("درجه / Click *"); val dose=field("دوز (اختیاری)"); val brew=field("دم‌افزار / روش (اختیاری)"); val notes=EditText(this).apply{hint="یادداشت (اختیاری)";minLines=3}
        listOf(coffee,grinder,setting,dose,brew,notes).forEach{box.addView(it,LinearLayout.LayoutParams(-1,if(it==notes)110 else 65))}
        val stamp=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date()); val date=TextView(this).apply{text="زمان ثبت: $stamp";setPadding(0,12,0,12)};box.addView(date)
        AlertDialog.Builder(this).setTitle("ذخیره نمونه").setView(box).setNegativeButton("لغو",null).setPositiveButton("ذخیره",null).create().also{dialog->
            dialog.setOnShowListener{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                if(coffee.text.isBlank()||grinder.text.isBlank()||setting.text.isBlank()){Toast.makeText(this,"نام قهوه، آسیاب و درجه لازم است.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
                val r=lastReport?:return@setOnClickListener; val s=Sample(0,coffee.text.toString().trim(),grinder.text.toString().trim(),setting.text.toString().trim(),dose.text.toString().trim(),brew.text.toString().trim(),notes.text.toString().trim(),System.currentTimeMillis(),num("D10:",r),num("D50:",r),num("D90:",r),particles(r),r,lastImagePath ?: "")
                db.insert(s); Toast.makeText(this,"نمونه ذخیره شد ✓",Toast.LENGTH_SHORT).show(); dialog.dismiss(); saveButton.visibility=View.GONE
            }};dialog.show()}
    }
}
