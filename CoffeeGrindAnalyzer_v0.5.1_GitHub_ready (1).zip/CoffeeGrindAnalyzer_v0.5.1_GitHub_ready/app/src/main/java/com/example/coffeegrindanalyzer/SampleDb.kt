package com.example.coffeegrindanalyzer

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Sample(
    val id: Long, val coffee: String, val grinder: String, val setting: String,
    val dose: String, val brew: String, val notes: String, val date: Long,
    val d10: Double, val d50: Double, val d90: Double, val particles: Int,
    val report: String, val imagePath: String
)

class SampleDb(context: Context) : SQLiteOpenHelper(context, "coffee_grind.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT, coffee TEXT NOT NULL, grinder TEXT, setting TEXT,
            dose TEXT, brew TEXT, notes TEXT, date INTEGER NOT NULL,
            d10 REAL, d50 REAL, d90 REAL, particles INTEGER, report TEXT, image_path TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(s: Sample): Long {
        val v = ContentValues().apply {
            put("coffee", s.coffee); put("grinder", s.grinder); put("setting", s.setting)
            put("dose", s.dose); put("brew", s.brew); put("notes", s.notes); put("date", s.date)
            put("d10", s.d10); put("d50", s.d50); put("d90", s.d90); put("particles", s.particles)
            put("report", s.report); put("image_path", s.imagePath)
        }
        return writableDatabase.insert("samples", null, v)
    }

    fun all(): List<Sample> = query(null, null)
    fun byCoffee(coffee: String): List<Sample> = query("coffee=?", arrayOf(coffee))
    fun coffees(): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        readableDatabase.rawQuery("SELECT coffee, COUNT(*) FROM samples GROUP BY coffee ORDER BY MAX(date) DESC", null).use { c ->
            while (c.moveToNext()) out += c.getString(0) to c.getInt(1)
        }
        return out
    }
    fun delete(id: Long) { writableDatabase.delete("samples", "id=?", arrayOf(id.toString())) }

    private fun query(sel: String?, args: Array<String>?): List<Sample> {
        val out = mutableListOf<Sample>()
        readableDatabase.query("samples", null, sel, args, null, null, "date DESC").use { c ->
            while (c.moveToNext()) out += Sample(
                c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("coffee")),
                c.getString(c.getColumnIndexOrThrow("grinder")), c.getString(c.getColumnIndexOrThrow("setting")),
                c.getString(c.getColumnIndexOrThrow("dose")), c.getString(c.getColumnIndexOrThrow("brew")),
                c.getString(c.getColumnIndexOrThrow("notes")), c.getLong(c.getColumnIndexOrThrow("date")),
                c.getDouble(c.getColumnIndexOrThrow("d10")), c.getDouble(c.getColumnIndexOrThrow("d50")),
                c.getDouble(c.getColumnIndexOrThrow("d90")), c.getInt(c.getColumnIndexOrThrow("particles")),
                c.getString(c.getColumnIndexOrThrow("report")), c.getString(c.getColumnIndexOrThrow("image_path"))
            )
        }
        return out
    }
}
